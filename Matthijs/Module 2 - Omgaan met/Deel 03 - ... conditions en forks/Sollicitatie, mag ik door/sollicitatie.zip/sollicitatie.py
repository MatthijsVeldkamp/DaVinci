import os
import time
x = True
while x == True:
    os.system('cls')
    print("Wat is uw naam?")
    naam = input("? ")
    os.system('cls')
    print("Welkom",naam,)
    print("------------------------------------------")
    print("|                                        |")
    print("| U gaat een aantal vragen beantwoorden. |")
    print("| Hierna ziet u of u mag solliciteren.   |")
    print("|                                        |")
    print("|          veel Succes!                  |")
    print("|                                        |")
    print("------------------------------------------")
    time.sleep(3)
    print("U gaat automatisch verder over 5 seconden...")
    time.sleep(5)
    os.system('cls')
    gender = str(input("Bent u een man of vrouw? "))
    if gender.lower() == "man":
        geslacht = 1
    elif gender.lower() == "vrouw":
        geslacht = 2    
    else:
        print("Er ging iets fout.")
        break
    check = 0
    print("Hoeveel jaar praktijkervaring heeft u met dieren-dressuur?")
    praktijk = input("? ")
    print("Hoeveel jaar ervaring heeft u met jongleren?")
    jongleren = input("? ")
    print("Hoeveel jaar praktijkervaring heeft u met acrobatiek?")
    acrobatiek = input("? ")
    acrobatiekfloat = float(acrobatiek)
    jonglerenfloat = float(jongleren)
    praktijkfloat = float(praktijk)
    if praktijkfloat > 4:
        check += 1
    elif acrobatiekfloat > 3:
        check += 1
    elif jonglerenfloat > 5:
        check += 1
    else:
        check += 0
    floatpraktijk = float(praktijk)
    if floatpraktijk > 4:
        check += 1
    else:
        check += 0

    diploma = str(input("Heeft u een MBO-4 diploma ondernemen? "))
    if diploma.lower() == "ja":
        check += 1
   
    elif diploma.lower() == "nee":
        check += 0
    else:
        print("Er ging iets fout.")
        break

    certificaat = str(input("Heeft u het certificaat overleven met gevaarlijk personeel? "))
    if certificaat.lower() == "ja":
        check += 1
    elif certificaat.lower() == "nee":
        check += 0
    else:
        print("Er ging iets fout.")
        break


    
    rijbewijs = str(input("Heeft u een vrachtwagen rijbewijs? "))
    if rijbewijs.lower() == "ja":
        check += 1
   
    elif rijbewijs.lower() == "nee":
        check += 0
    else:
        print("Er ging iets fout.")
        break
    
    hoed = str(input("Heeft u een hoge hoed? "))
    if hoed.lower() == "ja":
        check += 1
    
    elif hoed.lower() == "nee":
        check += 0
    else:
        print("Er ging iets fout.")
        break
    
    if geslacht == 1:
        print("Wat is uw snorlengte in centimeters?")
        snor = input("? ")
        floatsnor = float(snor)
        if floatsnor > 10:
            check += 1
        
        else:
            check += 0
    elif geslacht == 2:
        print("Wat is uw krulhaarlengte in centimeters?")
        haar = input("? ")
        floathaar = float(haar)
        if floathaar > 20:
            check += 1
        
        else:
            check += 0
    print("Wat is uw gewicht in hele kg?")
    kilo = input("? ")
    floatkilo = float(kilo)
    if floatkilo > 90:
        check += 1
        
    else:
        check += 0
    print("Wat is uw lengte in hele cm?")
    lengte = input("? ")
    floatlengte = float(lengte)
    if floatlengte > 150:
        check += 1
    
    else:
        check += 0

    if check == 9:
        os.system('cls')
        print("-------------------------------------------")
        print("|            Gefeliciteerd!               |")
        print("|                                         |")
        print("|                                         |")
        print("|          U mag solliciteren             |")
        print("-------------------------------------------")
        time.sleep(5)
        os.system('cls')
        break
    else:
        os.system('cls')
        print("-------------------------------------------")
        print("|                Helaas!                  |")
        print("|                                         |")
        print("|                                         |")
        print("|        U mag niet solliciteren          |")
        print("-------------------------------------------")
        time.sleep(5)
        os.system('cls')
        break